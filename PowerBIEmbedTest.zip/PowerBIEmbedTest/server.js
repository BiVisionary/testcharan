const express = require("express");
const axios = require("axios");
const bodyParser = require("body-parser");
const app = express();
app.use(bodyParser.json());

// 🔑 Replace with your actual values
const tenantId = "e550d334-50a2-468c-9c6b-9af08e6d4a34"; // Tenant ID
const clientId = " 312e99cf-5034-4252-b158-41a25197ab54"; // Azure AD App ID
const clientSecret = "rk78Q~OdxAk2d4G4ZlMOef_mVEg-j49Zi1EPLbR4"; // Azure AD App Secret
const workspaceId = "f142ef5d-e58a-4b29-bd31-ad36d2d51d45"; // Power BI Workspace ID
const reportId = "7ae2661d-472a-4a5c-a4d9-5ad5f6e82d7f"; // Report ID
const datasetId = "511948ea-98f5-44be-af12-f22bb4b32a91"; // Dataset ID

// 1. Get Azure AD token
async function getAccessToken() {
  const url = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
  const params = new URLSearchParams();
  params.append("grant_type", "client_credentials");
  params.append("client_id", clientId);
  params.append("client_secret", clientSecret);
  params.append("scope", "https://analysis.windows.net/powerbi/api/.default");
  
  const res = await axios.post(url, params);
  return res.data.access_token;
}

// 2. Generate Embed Token (WITHOUT RLS)
async function getEmbedToken() {
  const accessToken = await getAccessToken();
  const url = `https://api.powerbi.com/v1.0/myorg/groups/${workspaceId}/reports/${reportId}/GenerateToken`;
  
  const body = {
    reports: [{ id: reportId }],
    datasets: [{ id: datasetId }],
    targetWorkspaces: [{ id: workspaceId }],
    accessLevel: "View"
    // ✅ Removed identities parameter - No RLS applied
  };

  const res = await axios.post(url, body, {
    headers: { 
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });
  return res.data;
}

// 👉 Root route
app.get("/", (req, res) => {
  res.send(`
    <div style="font-family: Arial; padding: 40px; text-align: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; margin: 0;">
      <div style="background: white; padding: 30px; border-radius: 10px; display: inline-block; box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
        <h1 style="color: #333; margin-bottom: 20px;">🚀 Power BI Embed Server</h1>
        <p style="color: #666; margin-bottom: 30px;">Your server is running successfully!</p>
        <div style="margin: 20px 0;">
          <a href="/report" style="background: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 10px; display: inline-block;">📊 View Power BI Report</a>
          <a href="/getEmbedInfo" style="background: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin: 10px; display: inline-block;">🔑 Get Embed Token (JSON)</a>
        </div>
      </div>
    </div>
  `);
});

// 👉 Serve the HTML report page
app.get("/report", (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Power BI Embedded Report</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
            color: white;
            padding: 20px;
            text-align: center;
        }
        
        .header h1 {
            margin: 0;
            font-size: 2.2em;
            font-weight: 300;
        }
        
        .status {
            padding: 15px 20px;
            background: #f8f9fa;
            border-left: 4px solid #007bff;
            margin: 0;
            font-size: 14px;
        }
        
        .status.loading {
            border-left-color: #ffc107;
            background: #fff3cd;
            color: #856404;
        }
        
        .status.success {
            border-left-color: #28a745;
            background: #d4edda;
            color: #155724;
        }
        
        .status.error {
            border-left-color: #dc3545;
            background: #f8d7da;
            color: #721c24;
        }
        
        .report-container {
            height: 600px;
            position: relative;
            background: #f8f9fa;
        }
        
        #reportContainer {
            width: 100%;
            height: 100%;
            border: none;
        }
        
        .loading-spinner {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            flex-direction: column;
        }
        
        .spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid #007bff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .user-info {
            padding: 10px 20px;
            background: #e9ecef;
            font-size: 12px;
            color: #6c757d;
            border-top: 1px solid #dee2e6;
        }
        
        .refresh-btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            margin-left: 10px;
        }
        
        .refresh-btn:hover {
            background: #0056b3;
        }
        
        .refresh-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Power BI Dashboard</h1>
        </div>
        
        <div id="status" class="status loading">
            🔄 Loading report configuration...
        </div>
        
        <div class="report-container">
            <div id="loadingSpinner" class="loading-spinner">
                <div class="spinner"></div>
                <p style="margin-top: 20px; color: #6c757d;">Loading Power BI Report...</p>
            </div>
            <div id="reportContainer"></div>
        </div>
        
        <div class="user-info">
            <span id="userInfo">Loading information...</span>
            <button id="refreshBtn" class="refresh-btn" onclick="loadReport()">Refresh Report</button>
        </div>
    </div>

    <!-- Power BI JavaScript SDK -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/powerbi-client/2.22.1/powerbi.min.js"></script>
    
    <script>
        let report = null;
        
        function updateStatus(message, type = 'loading') {
            const statusEl = document.getElementById('status');
            statusEl.textContent = message;
            statusEl.className = \`status \${type}\`;
        }
        
        function showLoading(show = true) {
            document.getElementById('loadingSpinner').style.display = show ? 'flex' : 'none';
            document.getElementById('reportContainer').style.display = show ? 'none' : 'block';
        }
        
        async function loadReport() {
            const refreshBtn = document.getElementById('refreshBtn');
            refreshBtn.disabled = true;
            refreshBtn.textContent = 'Loading...';
            
            try {
                showLoading(true);
                updateStatus('🔄 Fetching embed token from server...', 'loading');
                
                // Fetch embed info from your server
                const response = await fetch('/getEmbedInfo');
                
                if (!response.ok) {
                    throw new Error(\`Server error: \${response.status} \${response.statusText}\`);
                }
                
                const embedInfo = await response.json();
                
                updateStatus('🔧 Configuring Power BI report...', 'loading');
                
                // Update info display
                document.getElementById('userInfo').textContent = 
                    \`📅 Last Updated: \${new Date().toLocaleString()}\`;
                
                // Power BI embed configuration
                const config = {
                    type: 'report',
                    tokenType: 1, // Embed token
                    accessToken: embedInfo.embedToken,
                    embedUrl: embedInfo.embedUrl,
                    id: embedInfo.reportId,
                    permissions: 1, // View permissions
                    settings: {
                        filterPaneEnabled: true,
                        navContentPaneEnabled: true,
                        layoutType: 0, // Custom
                        customLayout: {
                            displayOption: 1 // FitToPage
                        }
                    }
                };
                
                // Get reference to the HTML element
                const reportContainer = document.getElementById('reportContainer');
                
                // Embed the report
                report = powerbi.embed(reportContainer, config);
                
                // Handle events
                report.on('loaded', () => {
                    console.log('✅ Report loaded successfully');
                    updateStatus('✅ Report loaded successfully!', 'success');
                    showLoading(false);
                });
                
                report.on('rendered', () => {
                    console.log('✅ Report rendered successfully');
                    updateStatus('✅ Report is ready for interaction', 'success');
                });
                
                report.on('error', (event) => {
                    console.error('❌ Report error:', event.detail);
                    updateStatus(\`❌ Report error: \${event.detail}\`, 'error');
                    showLoading(false);
                });
                
            } catch (error) {
                console.error('❌ Error loading report:', error);
                updateStatus(\`❌ Failed to load report: \${error.message}\`, 'error');
                showLoading(false);
            } finally {
                refreshBtn.disabled = false;
                refreshBtn.textContent = 'Refresh Report';
            }
        }
        
        // Load report when page loads
        window.addEventListener('DOMContentLoaded', loadReport);
        
        // Auto-refresh token every 50 minutes (tokens expire in 1 hour)
        setInterval(() => {
            console.log('🔄 Auto-refreshing report token...');
            loadReport();
        }, 50 * 60 * 1000);
    </script>
</body>
</html>`);
});

// 👉 API endpoint for frontend (simplified without RLS)
app.get("/getEmbedInfo", async (req, res) => {
  try {
    console.log(`🔍 Generating embed token without RLS`);
    
    const tokenResponse = await getEmbedToken();
    
    console.log(`✅ Token generated successfully`);
    
    res.json({
      embedToken: tokenResponse.token,
      embedUrl: `https://app.powerbi.com/reportEmbed?reportId=${reportId}&groupId=${workspaceId}`,
      reportId: reportId
    });
  } catch (err) {
    console.error("❌ Error generating embed token:", err.response?.data || err.message);
    console.error("Full error:", err);
    res.status(500).json({
      error: "Failed to generate embed token",
      details: err.response?.data || err.message,
      timestamp: new Date().toISOString()
    });
  }
});

// Start server
app.listen(5000, () => {
  console.log("✅ Server running on http://localhost:5000");
  console.log("📊 Power BI Report: http://localhost:5000/report");
  console.log("🔑 Embed Token API: http://localhost:5000/getEmbedInfo");
  console.log("🏠 Home Page: http://localhost:5000");
});